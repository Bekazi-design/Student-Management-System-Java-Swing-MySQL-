/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.edumanage;

/**
 *
 * @author User
 */
public class EduManage {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
