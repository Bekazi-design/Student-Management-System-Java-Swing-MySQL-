/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package my_package;

import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author User
 */
public class DBConnection {
    
  
    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/student_system",
                "root",
                ""
            );

            System.out.println("Connected to database!");
            return con;

        } catch (Exception e) {
            System.out.println("Connection error:");
            e.printStackTrace(); // VERY IMPORTANT
            return null;
        }
    }
}

