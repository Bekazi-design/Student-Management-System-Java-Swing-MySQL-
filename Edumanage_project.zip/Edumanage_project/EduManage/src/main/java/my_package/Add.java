/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package my_package;

import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author User
 */
public class Add extends javax.swing.JFrame {
    
    private void addplaceholders(){
        
        jTextField1.addFocusListener(new java.awt.event.FocusAdapter() {
        @Override
        
        public void focusGained(java.awt.event.FocusEvent e) {
            if (jTextField1.getText().equals ("Name"))jTextField1.setText("");
            
        }
        @Override
        public void focusLost (java.awt.event.FocusEvent e){
        if (jTextField1.getText().isEmpty ()) jTextField1.setText("Name");
    }
         
     });
        
        jTextField2.addFocusListener( new java.awt.event.FocusAdapter() {
            @Override 
            
             public void focusGained(java.awt.event.FocusEvent e){
                 if (jTextField2.getText().equals("Surname"))jTextField2.setText("");
                 
             }
             @Override 
             
             public void focusLost(java.awt.event.FocusEvent e){
                 if (jTextField2.getText().isEmpty ())jTextField2.setText("Surname");
             }
            
            
        });
       
        
           jTextField3.addFocusListener( new java.awt.event.FocusAdapter() {
            @Override 
            
             public void focusGained(java.awt.event.FocusEvent e){
                 if (jTextField3.getText().equals("Age"))jTextField3.setText("");
                 
             }
             @Override 
             
             public void focusLost(java.awt.event.FocusEvent e){
                 if (jTextField3.getText().isEmpty ())jTextField3.setText("Age");
             }
            
            
        });
        jTextField4.addFocusListener( new java.awt.event.FocusAdapter() {
            @Override 
            
             public void focusGained(java.awt.event.FocusEvent e){
                 if (jTextField4.getText().equals("Student No"))jTextField4.setText("");
                 
             }
             @Override 
             
             public void focusLost(java.awt.event.FocusEvent e){
                 if (jTextField4.getText().isEmpty ())jTextField4.setText("Student No");
             }
            
            
        });
        jTextField5.addFocusListener( new java.awt.event.FocusAdapter() {
            @Override 
            
             public void focusGained(java.awt.event.FocusEvent e){
                 if (jTextField5.getText().equals("Avarage"))jTextField5.setText("");
                 
             }
             @Override 
             
             public void focusLost(java.awt.event.FocusEvent e){
                 if (jTextField5.getText().isEmpty ())jTextField5.setText("Avarage");
             }
            
            
        });
       
        
      
        
        
        
        
        
        
    }
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Add.class.getName());

    /**
     * Creates new form Add
     */
    public Add() {
        initComponents();
        
          //
          
          
          
          addplaceholders();
        
        // SIGNIN BUTTON ACTION
    jButton2.addActionListener(e -> {
        
        
  

    try {
        Connection con = DBConnection.getConnection();

        // 👉 ADD THIS BLOCK HERE
        if (con == null) {
            JOptionPane.showMessageDialog(this, "Database connection FAILED!");
            return;
        } else {
            JOptionPane.showMessageDialog(this, "Connected successfully!");
        }

        String sql = "INSERT INTO students (student_number, name, surname, age, gender, course, average) VALUES (?, ?, ?, ?, ?, ?, ?)";

        PreparedStatement pst = con.prepareStatement(sql);
    

        // GET VALUES FROM FIELDS
        String studentNumber = jTextField4.getText();
        String name = jTextField1.getText();
        String surname = jTextField2.getText();
        int age = Integer.parseInt(jTextField3.getText());
        String gender = jComboBox1.getSelectedItem().toString();
        String course = jComboBox2.getSelectedItem().toString();
        double average = Double.parseDouble(jTextField5.getText());

        // SET VALUES INTO QUERY
        pst.setString(1, studentNumber);
        pst.setString(2, name);
        pst.setString(3, surname);
        pst.setInt(4, age);
        pst.setString(5, gender);
        pst.setString(6, course);
        pst.setDouble(7, average);

        pst.executeUpdate();

        JOptionPane.showMessageDialog(this, "Student Saved to Database!");

        // CLEAR FIELDS AFTER SAVE
        jTextField1.setText("Name");
        jTextField2.setText("Surname");
        jTextField3.setText("Age");
        jTextField4.setText("Student No");
        jTextField5.setText("Avarage");

    } catch (Exception ex) {
        JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        ex.printStackTrace();
    }

});

   
    jButton3.addActionListener(e -> {
        new Edumain().setVisible(true);
        this.dispose();
    });
    jButton4.addActionListener(e -> {
        new Add().setVisible(true);
        this.dispose();
    });
    
    jButton5.addActionListener(e-> {
        new All().setVisible(true);
        this.dispose();
        
    });
    
    // SETTINGS BUTTON (placeholder)
     jButton6.addActionListener(e -> {
     javax.swing.JOptionPane.showMessageDialog(
        null,
        "Settings are not available yet.",
        "Info",
        javax.swing.JOptionPane.INFORMATION_MESSAGE
    );
});
    
            
            }
            
    /**{
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jTextField5 = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jComboBox2 = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();

        jButton1.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Add New Student ");

        jTextField1.setText("Name");

        jTextField2.setText("Surname");

        jTextField3.setText("Age");
        jTextField3.addActionListener(this::jTextField3ActionPerformed);

        jTextField4.setText("Student No");
        jTextField4.addActionListener(this::jTextField4ActionPerformed);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Gender", "Male", "Female", " " }));
        jComboBox1.addActionListener(this::jComboBox1ActionPerformed);

        jTextField5.setText("Avarage");
        jTextField5.addActionListener(this::jTextField5ActionPerformed);

        jButton2.setText("Add student ");

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "course", "Networking & Infrastructure", "Software Development", "Computer science", "Cybersecurity", "Data science", "Systems & Support", "Business IT", "System Analyst ", " " }));

        jPanel1.setBackground(new java.awt.Color(51, 51, 255));
        jPanel1.setForeground(new java.awt.Color(102, 255, 102));
        jPanel1.setPreferredSize(new java.awt.Dimension(122, 255));

        jButton3.setText("Home Board");

        jButton4.setText("Add Student ");

        jButton5.setText("View Students");

        jButton6.setText("Settings");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton5, javax.swing.GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
                    .addComponent(jButton6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jButton3)
                .addGap(39, 39, 39)
                .addComponent(jButton4)
                .addGap(39, 39, 39)
                .addComponent(jButton5)
                .addGap(39, 39, 39)
                .addComponent(jButton6)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(136, 136, 136)
                                .addComponent(jButton2)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField2)
                            .addComponent(jTextField1)
                            .addComponent(jTextField3)
                            .addComponent(jTextField4)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 826, Short.MAX_VALUE)))
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(48, 48, 48)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 266, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addContainerGap())
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 588, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField4ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField5ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Add().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    // End of variables declaration//GEN-END:variables
}
