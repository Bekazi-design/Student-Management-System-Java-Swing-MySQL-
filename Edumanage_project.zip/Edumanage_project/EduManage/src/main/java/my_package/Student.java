/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package my_package;

/**
 *
 * @author User
 */
public class Student {
    
    String studentNumber;
    String name;
    String surname;
    int age;
    String gender;
    String course;
    double average;
    
}
