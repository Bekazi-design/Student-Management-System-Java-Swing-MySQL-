/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package my_package;

import java.awt.Color;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Connection;



/**
 *
 * @author User
 */
public class Signin extends javax.swing.JFrame {
    
    
    
  private void registerUser() {
    try {
        Connection con = DBConnection.getConnection();

         String email = jTextField1.getText();
         String password = new String(jPasswordField1.getPassword());
         String confirm = new String(jPasswordField2.getPassword());
         String role = jTextField6.getText();

        // VALIDATION
        if (email.equals("Email") || password.equals("Password")) {
            javax.swing.JOptionPane.showMessageDialog(this, "Please fill all fields");
            return;
        }

        if (!password.equals(confirm)) {
            javax.swing.JOptionPane.showMessageDialog(this, "Passwords do not match");
            return;
        }

        // ONLY ADMIN OR STAFF CAN REGISTER
        if (!role.equalsIgnoreCase("admin") && !role.equalsIgnoreCase("staff")) {
            javax.swing.JOptionPane.showMessageDialog(this, "Only admin or staff allowed");
            return;
        }

        String sql = "INSERT INTO users (username, password, role) VALUES (?, ?, ?)";
        PreparedStatement pst = con.prepareStatement(sql);

        pst.setString(1, email);
        pst.setString(2, password);
        pst.setString(3, role);

        pst.executeUpdate();

        javax.swing.JOptionPane.showMessageDialog(this, "Registered Successfully!");

    } catch (Exception e) {
        e.printStackTrace();
    }
}
    
    private void addPlaceholders() {
    // First Name
    jTextField4.addFocusListener(new java.awt.event.FocusAdapter() {
        @Override
        public void focusGained(java.awt.event.FocusEvent e) {
            if (jTextField4.getText().equals("First Name")) jTextField4.setText("");
        }
        @Override
        public void focusLost(java.awt.event.FocusEvent e) {
            if (jTextField4.getText().isEmpty()) jTextField4.setText("First Name");
        }
    });

    // Last Name
    jTextField5.addFocusListener(new java.awt.event.FocusAdapter() {
        @Override
        public void focusGained(java.awt.event.FocusEvent e) {
            if (jTextField5.getText().equals("Last Name")) jTextField5.setText("");
        }
        @Override
        public void focusLost(java.awt.event.FocusEvent e) {
            if (jTextField5.getText().isEmpty()) jTextField5.setText("Last Name");
        }
    });

    // Email
    jTextField1.addFocusListener(new java.awt.event.FocusAdapter() {
        @Override
        public void focusGained(java.awt.event.FocusEvent e) {
            if (jTextField1.getText().equals("Email")) jTextField1.setText("");
        }
        @Override
        public void focusLost(java.awt.event.FocusEvent e) {
            if (jTextField1.getText().isEmpty()) jTextField1.setText("Email");
        }
    });

    // Password
    jPasswordField1.setEchoChar((char)0); // show placeholder initially
    jPasswordField1.addFocusListener(new java.awt.event.FocusAdapter() {
        @Override
        public void focusGained(java.awt.event.FocusEvent e) {
            if (new String(jPasswordField1.getPassword()).equals("Password")) {
                jPasswordField1.setText("");
                jPasswordField1.setEchoChar('•'); // hide password
            }
        }
        @Override
        public void focusLost(java.awt.event.FocusEvent e) {
            if (jPasswordField1.getPassword().length == 0) {
                jPasswordField1.setText("Password");
                jPasswordField1.setEchoChar((char)0); // show placeholder
            }
        }
    });

    // Confirm Password
    jPasswordField2.setEchoChar((char)0); // show placeholder initially
    jPasswordField2.addFocusListener(new java.awt.event.FocusAdapter() {
        @Override
        public void focusGained(java.awt.event.FocusEvent e) {
            if (new String(jPasswordField2.getPassword()).equals("Confirm password")) {
                jPasswordField2.setText("");
                jPasswordField2.setEchoChar('•'); // hide password
            }
        }
        @Override
        public void focusLost(java.awt.event.FocusEvent e) {
            if (jPasswordField2.getPassword().length == 0) {
                jPasswordField2.setText("Confirm password");
                jPasswordField2.setEchoChar((char)0); // show placeholder
            }
        }
    });
    
    // Role
jTextField6.addFocusListener(new java.awt.event.FocusAdapter() {
    @Override
    public void focusGained(java.awt.event.FocusEvent e) {
        if (jTextField6.getText().equals("Role")) {
            jTextField6.setText("");
        }
    }

    @Override
    public void focusLost(java.awt.event.FocusEvent e) {
        if (jTextField6.getText().isEmpty()) {
            jTextField6.setText("Role");
        }
    }
});

    // Optional: double-click to toggle visibility
    jPasswordField1.addMouseListener(new java.awt.event.MouseAdapter() {
        private boolean visible = false;
        @Override
        public void mouseClicked(java.awt.event.MouseEvent e) {
            if (e.getClickCount() == 2) {
                visible = !visible;
                jPasswordField1.setEchoChar(visible ? (char)0 : '•');
            }
        }
    });

    jPasswordField2.addMouseListener(new java.awt.event.MouseAdapter() {
        private boolean visible = false;
        @Override
        public void mouseClicked(java.awt.event.MouseEvent e) {
            if (e.getClickCount() == 2) {
                visible = !visible;
                jPasswordField2.setEchoChar(visible ? (char)0 : '•');
            }
        }
    });
}
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Signin.class.getName());

    /**
     * Creates new form Signin
     */
    public Signin() {
        initComponents();
        
       

    // Title style
  
    
    
    //FIRST NAME 
    jTextField4.setBorder(new RoundedBorder(20));
    jTextField4.setColumns(14); 
    
    
    
    //LAST NAME
    jTextField5.setBorder(new RoundedBorder(20));
    jTextField5.setColumns(14); 
    
    
    
    
    // PASSWORD
     jPasswordField1.setBorder(new RoundedBorder(20));
     jPasswordField1.setColumns(24);
     jPasswordField1.setText("Password");
     jPasswordField1.setEchoChar((char)0);

// CONFIRM PASSWORD
    jPasswordField2.setBorder(new RoundedBorder(20));
    jPasswordField2.setColumns(24);
    jPasswordField2.setText("Confirm password");
    jPasswordField2.setEchoChar((char)0); 
    //email
    jTextField1.setBorder(new RoundedBorder(20));
    jTextField1.setColumns(24); 
    
     jTextField6.setBorder(new RoundedBorder(20));
     jTextField6.setColumns(24); 
     
     
    
    
    
    addPlaceholders();
    
    // SIGNIN BUTTON ACTION
    jButton2.addActionListener(e -> {
        new Login().setVisible(true); 
        this.dispose(); 
    
     });
    
   jButton1.addActionListener(e -> {
    registerUser();
});
    
    


    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        jPasswordField1 = new javax.swing.JPasswordField();
        jPasswordField2 = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(204, 204, 255));
        setForeground(new java.awt.Color(153, 153, 255));

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI Semilight", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 181, 183));
        jLabel1.setText("Register");
        jLabel1.setVerticalTextPosition(javax.swing.SwingConstants.TOP);

        jTextField1.setText("Email");
        jTextField1.addActionListener(this::jTextField1ActionPerformed);

        jTextField4.setText("First Name");

        jTextField5.setText("Last Name");

        jButton1.setBackground(new java.awt.Color(102, 255, 255));
        jButton1.setText("Submit");

        jLabel2.setText("Already have an account?");

        jButton2.setBackground(new java.awt.Color(51, 0, 255));
        jButton2.setText("Signin");
        jButton2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Serif", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 0, 255));
        jLabel3.setText("Create your administrator account to manage students, courses, and reports.");

        jTextField6.setText("Role");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(109, 109, 109)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(76, 76, 76)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextField1)
                    .addComponent(jTextField6, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPasswordField1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 411, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPasswordField2, javax.swing.GroupLayout.DEFAULT_SIZE, 900, Short.MAX_VALUE))
                .addGap(67, 67, 67))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jPasswordField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 269, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jButton2))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
      
    }//GEN-LAST:event_jTextField1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
       
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Signin().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JPasswordField jPasswordField2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    // End of variables declaration//GEN-END:variables
}
